-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2022 at 01:16 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supermarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminl`
--

CREATE TABLE `adminl` (
  `Name` varchar(20) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `ContactNo` varchar(10) NOT NULL,
  `AworkID` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `adminl`
--

INSERT INTO `adminl` (`Name`, `NIC`, `ContactNo`, `AworkID`, `Password`) VALUES
('', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cashier`
--

CREATE TABLE `cashier` (
  `Name` varchar(20) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `ContactNo` int(10) NOT NULL,
  `CworkID` varchar(15) NOT NULL,
  `Cpassword` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cashier`
--

INSERT INTO `cashier` (`Name`, `NIC`, `ContactNo`, `CworkID`, `Cpassword`) VALUES
('roshana', '123455', 231213213, 'R001', '1234'),
('Lakmal', '200003601807', 765498745, 'U001', 'Lakmal'),
('Yasitha Madushan', '21212121', 771112, 'YasithaCa', 'yasitha123');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CustomerName` varchar(15) NOT NULL,
  `NIC` varchar(15) NOT NULL,
  `Contact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductName` varchar(15) NOT NULL,
  `Category` varchar(15) NOT NULL,
  `WholesalePrice` double NOT NULL,
  `RetailPrice` double NOT NULL,
  `ProductCode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductName`, `Category`, `WholesalePrice`, `RetailPrice`, `ProductCode`) VALUES
('amba', 'Fruit', 15, 20, 'a1'),
('orange`', 'Fruit', 15, 25, 'Fruit01'),
('kehel', 'Fruit', 10, 20, 'K1'),
('pkaauya', 'Vegetables', 150, 200, 'kjb132132'),
('Tomato', 'Vegetables', 57, 80, 'Ve001'),
('wattakka', 'Vegetables', 150, 250, 'w1');

-- --------------------------------------------------------

--
-- Table structure for table `securityqs`
--

CREATE TABLE `securityqs` (
  `WorkID` varchar(15) NOT NULL,
  `SecurityQ01` varchar(15) NOT NULL,
  `SecurityQ02` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `SuplierName` varchar(20) NOT NULL,
  `SupplierID` varchar(10) NOT NULL,
  `ProductCatogory` varchar(15) NOT NULL,
  `SuplierContact` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`SuplierName`, `SupplierID`, `ProductCatogory`, `SuplierContact`) VALUES
('SDU', 'S001', 'Pharmaceuticals', '0754871234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminl`
--
ALTER TABLE `adminl`
  ADD PRIMARY KEY (`AworkID`);

--
-- Indexes for table `cashier`
--
ALTER TABLE `cashier`
  ADD PRIMARY KEY (`CworkID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`NIC`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductCode`);

--
-- Indexes for table `securityqs`
--
ALTER TABLE `securityqs`
  ADD PRIMARY KEY (`WorkID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`SupplierID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
